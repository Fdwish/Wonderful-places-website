<DOCTYOE html!>

<html>
	<head>
		<title>
					information Technology Department
		</title>
		
		<<link rel="stylesheet" href="s.css">
	</head>
	
		<body>
		
		<header>
			 <div class="header" > 
			<h1> contact Us </h1>
			<br>
			</div>
			<?php
				include "header.php";
			?>
			
			
			
			</header>
		<div style="padding-top: 2%; padding-right: 2%; text-align: right">
			<p id="p1"></p>
			<p id="p2"></p>
			<script src="DateTime.js"></script>
		</div>
			<div class="container">
			<pre class="tab">
<h4>For any questions regarding our site,contact us in the following ways:</h4>
<p>Email: <a href="mailto:contactus@edu.Imamu.gov.sa">contactus@.eduImamu.gov.sa</a><br>
 Telephone: 920011111 
	</p>
	</pre>
	</div>
	
	
	<div class="footer">
	<p>	@copyright 2018 </p>

	</div>
	
	

			
		</body>





</html>