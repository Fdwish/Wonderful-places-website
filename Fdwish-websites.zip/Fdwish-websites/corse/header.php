<nav>
			<ul>  
					
					<li><a href ="home.php">Home</a> </li>
					<li> <a href ="courses.php">Coures</a> </li>
					<li><a href ="add_course.php">Add Course</a> </li>
					<li> <a href ="contactus.php">Contact us</a> </li>
					 
					<li>
                   <a label id="lblGreetings"></label>
					<script src="Greeting.js"></script>
                    </li>
					
</ul>		
</nav>