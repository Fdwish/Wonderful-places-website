<DOCTYOE html!>

<html>
	<head>
		<title>
					information Technology Department
		</title>
		
		<<link rel="stylesheet" href="s.css">
	</head>
	
		<body>
		
		<header>
			 <div class="header" > 
			<h1> IT Department </h1>
			<br>
			</div>
			<?php
				include "header.php";
			?>
			
			
			
			</header>
		<div style="padding-top: 2%; padding-right: 2%; text-align: right">
			<p id="p1"></p>
			<p id="p2"></p>
			<script src="DateTime.js"></script>
		</div>
			<div class="container">
			<pre class="tab">
			  <h2>Overview</h2>
<p>   I would like to welcome you to the course website of the Information 

   Technology Department at the Imam Muhammad bin Saud Islamic University.
   
   The website aims to add courses to Information Technology Department 
   
   IT department undertook new tasks that ensure that the computing infrastructure 
   
   is suitable for any organization to operate efficiently and reliability,
   
   and meet the computer-related needs of individuals, and developing appropriate 
   
   solutions for problems. Today, all kinds of organizations dramatically rely on 
   
   IT departments. They need to have appropriate regulations,and is working properly,
   
    and to be locked and are constantly updated and maintained in a timely manner.
	
	</p>	
	</pre>
	</div>
	
	
	<div class="footer">
	<p>	@copyright 2018 </p>

	</div>
	
	

			
		</body>





</html>